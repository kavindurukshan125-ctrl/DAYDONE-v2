# DAYDONE — Android App Project

This is the Android Studio project for the DAYDONE app.

## What this version does
- Packages the DAYDONE HTML app inside an Android APK using a WebView.
- Uses AndroidX WebKit `WebViewAssetLoader` for local app assets instead of unsafe `file://` loading.
- Supports Android photo selection through the native file picker.
- Requests Android 13+ notification permission.
- Syncs DAYDONE reminder times to native Android daily inexact alarms, so reminders can appear even when the WebView isn't open.
- Keeps the existing profile, tasks, XP, streak, goals, stats and animation UI.
- Includes the DAYDONE icon and both icon option images.
- Uses an abstract neon visual in Settings instead of relying on a browser-only video file.

## Build
Open this folder in Android Studio and let Gradle sync. The project uses:
- compileSdk 36
- targetSdk 36
- minSdk 24
- Android Gradle Plugin 8.13.2
- AndroidX WebKit 1.17.0

Android Studio/Gradle will download the required SDK/dependencies when connected to the internet.

## Important
The current environment does not have the Android SDK/Gradle toolchain installed, so an APK cannot be compiled here. The project itself is ready to open and build in Android Studio.
