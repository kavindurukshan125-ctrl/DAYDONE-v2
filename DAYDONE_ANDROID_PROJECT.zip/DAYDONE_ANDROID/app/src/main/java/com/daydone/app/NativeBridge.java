package com.daydone.app;

import android.app.*; import android.content.*; import android.webkit.JavascriptInterface; import org.json.*; import java.util.*;

public class NativeBridge {
  private final MainActivity a; public NativeBridge(MainActivity a){this.a=a;}
  @JavascriptInterface public void requestNotifications(){ a.runOnUiThread(a::askNotification); }
  @JavascriptInterface public void syncReminders(String json){
    try{
      JSONObject root=new JSONObject(json); JSONArray arr=root.optJSONArray("reminders"); ReminderScheduler.clearAll(a);
      if(arr!=null) for(int i=0;i<arr.length();i++){JSONObject r=arr.getJSONObject(i); if(r.optBoolean("on",false)) ReminderScheduler.schedule(a,r.optString("time"),r.optString("name","DAYDONE Reminder"),i+1);}
      String custom=root.optString("customReminder",""); if(!custom.isEmpty()) ReminderScheduler.schedule(a,custom,"DAYDONE Custom Reminder",1000);
    }catch(Exception ignored){}
  }
}
