package com.daydone.app;

import android.app.*; import android.content.*; import java.util.*;

public class ReminderScheduler {
  static final String PREF="daydone_reminders";
  public static void clearAll(Context c){ AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE); for(int id:new int[]{1,2,3,4,1000}){PendingIntent p=pi(c,id);am.cancel(p);} }
  public static void schedule(Context c,String time,String title,int id){ int[] hm=parse(time); if(hm==null)return; Calendar cal=Calendar.getInstance(); cal.set(Calendar.HOUR_OF_DAY,hm[0]);cal.set(Calendar.MINUTE,hm[1]);cal.set(Calendar.SECOND,0);cal.set(Calendar.MILLISECOND,0); if(cal.getTimeInMillis()<=System.currentTimeMillis())cal.add(Calendar.DAY_OF_YEAR,1); AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE); am.setInexactRepeating(AlarmManager.RTC_WAKEUP,cal.getTimeInMillis(),AlarmManager.INTERVAL_DAY,pi(c,id)); c.getSharedPreferences(PREF,0).edit().putString("t"+id,title).apply(); }
  static int[] parse(String s){try{String x=s.trim().toUpperCase();String[] a=x.split("\\s+");String[] hm=a[0].split(":");int h=Integer.parseInt(hm[0]),m=Integer.parseInt(hm[1]);if(a.length>1){if(a[1].equals("PM")&&h<12)h+=12;if(a[1].equals("AM")&&h==12)h=0;}return new int[]{h,m};}catch(Exception e){return null;}}
  static PendingIntent pi(Context c,int id){Intent i=new Intent(c,ReminderReceiver.class).putExtra("id",id);return PendingIntent.getBroadcast(c,id,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}
}
