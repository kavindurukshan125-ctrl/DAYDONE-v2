package com.daydone.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.*;
import android.widget.FrameLayout;
import androidx.annotation.Nullable;
import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewClientCompat;
import org.json.*;
import java.util.*;

public class MainActivity extends android.app.Activity {
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_PICKER = 2001;
    private static final int NOTIF_PERMISSION = 2002;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        FrameLayout root = new FrameLayout(this); root.setBackgroundColor(0xFF07050D); setContentView(root);
        webView = new WebView(this); root.addView(webView, new FrameLayout.LayoutParams(-1,-1));
        WebSettings s = webView.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false); s.setAllowContentAccess(false);
        WebViewAssetLoader loader = new WebViewAssetLoader.Builder().addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        webView.setWebViewClient(new WebViewClientCompat(){ @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r){ return loader.shouldInterceptRequest(r.getUrl()); } @Override public WebResourceResponse shouldInterceptRequest(WebView v,String u){ return loader.shouldInterceptRequest(Uri.parse(u)); }});
        webView.setWebChromeClient(new WebChromeClient(){ @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p){
            if(fileCallback!=null) fileCallback.onReceiveValue(null); fileCallback=cb;
            Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("image/*"); startActivityForResult(i,FILE_PICKER); return true; }});
        webView.addJavascriptInterface(new NativeBridge(this),"Android");
        webView.loadUrl("https://appassets.androidplatform.net/assets/www/index.html");
    }
    @Override protected void onActivityResult(int req,int res,@Nullable Intent data){ super.onActivityResult(req,res,data); if(req==FILE_PICKER&&fileCallback!=null){ Uri[] out=null; if(res==RESULT_OK&&data!=null&&data.getData()!=null) out=new Uri[]{data.getData()}; fileCallback.onReceiveValue(out); fileCallback=null; }}
    public void askNotification(){ if(android.os.Build.VERSION.SDK_INT>=33) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},NOTIF_PERMISSION); else Toast.makeText(this,"Notifications are available on this Android version.",Toast.LENGTH_SHORT).show(); }
    @Override public void onBackPressed(){ if(webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
}
